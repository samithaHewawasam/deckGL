/// <reference types="react-scripts" />
declare module '@urbica/react-map-gl-draw'
